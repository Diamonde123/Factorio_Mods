data:extend(
{  
  {
    type = "research-achievement",
    name = "protoss-power",
    order = "a[progress]",
    technology = "pylon-restoration",
    icon_size = 64,
    icon = "__StarFactory__/graphics/tecnology/pylon-restoration.png",
  },
 }
)