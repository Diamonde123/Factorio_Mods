data:extend(
{
	{
		type = "recipe-category",
		name = "primitive-summoning"
	},
}
)