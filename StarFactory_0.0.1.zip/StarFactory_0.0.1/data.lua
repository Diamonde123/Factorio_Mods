require("prototypes.technology")

require("prototypes.recipes")
require("prototypes.recipe-categories")

require("prototypes.items")

require("prototypes.entity.entities")
require("prototypes.entity.warp-gates")
require("prototypes.entity.turrets")
require("prototypes.entity.projectiles")
